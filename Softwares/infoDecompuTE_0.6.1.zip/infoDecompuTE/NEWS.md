CHANGES IN infoDecompuTE VERSION 0.6.1

NEW FEATURES
  
  o To check with the latest version of R.
  
CHANGES IN infoDecompuTE VERSION 0.6

NEW FEATURES
  
  o To check with the latest version of R.


CHANGES IN infoDecompuTE VERSION 0.5.6

NEW FEATURES
  
  o allow the user to display the coefficients in the decimals instead of fraction.
  
  o stored the code on github, https://github.com/kcha193/infoDecompuTE
  

BUG FIXES

  o the constructing the block/treatment contrast matrix when the users defined
	their own. Focusing on when there are interaction effects.   

MAJOR CHANGES

  o remove the logical on fitting the model as contrast matrices. May need to 
	change back in the future.   